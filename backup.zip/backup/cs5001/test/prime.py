import sys
import math

def main():
    max = int(sys.argv[1])  #sys.argv is a list representing the user input
    i = 3
    print(3)
    for i in range(3, max+1, 2):
        is_prime = True
        k = 2
        while is_prime and k < math.sqrt(max):
            if i % k == 0:
                is_prime = False
            k += 1
        if is_prime:
            print(i)

main()