def main():
    total = 0
    count = 0
    average = 0
    while True:
        try:
            user_num = float(input("Input a value: "))
            total += user_num
            count += 1
            average = total/count
            print("Average so far:", average)
        except KeyboardInterrupt:
            return
main()