class Node():
    def __init__(self, value):
        self.value = value
        self.next = None

    def __repr__(self):
        p = self
        s = ""
        while p != None:
            s += str(p.value) + "->"
            p = p.next
        
        return s[:-2]

