int get_max(int a, int b){
    if (a > b){
        return a;
    }
    else{
        return b;
    }
}

float get_max(float a, float b){
    if (a > b){
        return a;
    }
    else{
        return b;
    }
}

void main(){
    int a = 2;
    int b = 3;
    int c = get_max(a, b);
    printf("%d", c);
}

main()