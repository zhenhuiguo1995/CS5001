def main():
    consent = 'y'
    while consent == 'y':
        input_string = input("Input a potential palindrome:")
        reverse = ""
        for i in range(0, len(input_string)):
            reverse += input_string[len(input_string)-i-1]
        if reverse == input_string:
            print(input_string,"is a palindrome")
        else:
            print(input_string,"is not a palindrome")

        """
        ind = 0
        while(ind <= len(word)/2 and word(ind) == word[-(ind +1)] ):
            ind += 1
        if ind <= len(word)/2:
            print(input_string,"is not a palindrome")
        else:
            print(input_string,"is a palindrome")
        """
        consent = input("Would you like to try another(y or n):")
    print("The game ends")

main()