class CharFreqs():
    def __init__(self):


    def add_char(self):


    def count_line(self):


    