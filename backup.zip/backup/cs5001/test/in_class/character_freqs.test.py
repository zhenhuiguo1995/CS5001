from character_freq import CharFreqs


def test_constructor():
    """Test the construtcor"""
    
def test_add_chars():
    """Test adding a character in the counter"""


def test_count_line():
    """Test counting characters in a line"""

