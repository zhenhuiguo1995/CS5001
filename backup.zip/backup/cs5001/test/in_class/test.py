import re
my_string = "ABCDE12345abcdefgLMNOP"
"""
* is greedniess
? is laziness
"""
my_string = re.sub(r".*([0-9]+)([a-z]+).*",
            r" Matched \1, \2", my_string)


print(my_string)