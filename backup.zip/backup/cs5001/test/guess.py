import random as rnd


def main():
    num = rnd.randint(1, 1000)
    guess = int(input("input a number:"))
    count = 1   
    while(guess != num):
        if guess < num:
            guess = int(input("too low, try again!:"))
        else:
            guess = int(input("too high, try again:"))
        count += 1
    if count == 1:
        print("Excellent! You tried it out with only 1 time")
    else:
        print("You tried it out with", count,"times!")

main()