# import the Person class from the person modular
from person import Person

def main():
    p1 = Person("Jack", 29)
    p1.inroduce_yourself()


main()


