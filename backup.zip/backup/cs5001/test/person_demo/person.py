class Person():
    """a class representing a person"""
    def __init__(self, name, age):
        self.name = name
        self.age = age
        self.friends = []

    def inroduce_yourself(self):
        print("My name is {0}, I am {1} year old.".format(self.name, self.age))
        if len(self.friends) > 0:
            self.introduce_friends()

    def introduce_friends(self):
        print("\tMy friends are:")
        for friend in self.friends:
            print("\t\t{0}".format(friend.name))

    def befriend(self, new_friend):
        self.friends.append(new_friend)
        new_friend.friends.append(self)

    def say_hello(self):
        print("Hello")
