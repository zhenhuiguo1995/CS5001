import sys

def main():
    width, height = int(sys.argv[1]), int(sys.argv[2])
    for _ in range(0, height):
        print("*"*width)

main()