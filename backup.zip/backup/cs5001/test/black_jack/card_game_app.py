from game_controller import GameController


def main():
    gc = GameController()

    print("--------------------------------")
    print("Welcome to simplified BlackJack!")

    gc.start_play()

main()
