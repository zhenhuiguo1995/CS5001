from hand import Hand
from card import Card


def test_hand_score()
    hand = Hand()
    hand.receive_card(Card('hearts', '9'))
    hand.receive_card(Card('hearts', 'ace'))
    hand.receive_card(Card('spades', 'ace'))
    print(hand.score)
    assert hand.score == 21


def main()
    pass
    # test_hand_score()


main()