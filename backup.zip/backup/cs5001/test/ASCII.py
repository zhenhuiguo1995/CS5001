def main():
    string = input("Please input a string:")
    ASCII = [ord(i) for i in string]
    zipped = list(zip(string, ASCII))
    for element in zipped:
        print(element)
    #out_put = [(string[i], ord(string[i])) for i in range(0, len(string))]
    #for i in range(0, len(out_put)):
    #    print(out_put[i])

main()