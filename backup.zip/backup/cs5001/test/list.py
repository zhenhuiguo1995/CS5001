food =["apple","banana","pearl","stawberries"]
animals = ["monkey","elephant","tigers","zebra"]
a = list(zip(food, animals))
#zip does not return a list
print(a)

str = "apples bananas  oranges"
a = str.split()
print(a[0])
print(ord('a'))
print(chr(49))