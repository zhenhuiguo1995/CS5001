import sys

def recursive(temp, number):
    if number == 1:
        temp.append(tri(1))
    else:
        temp.append(tri(number))
        recursive(temp, number- 1)


def tri(number):
    if number == 0:
        return 0
    else:
        return number + tri(number - 1)

def main():
    num = int(sys.argv[1])
    temp = []
    recursive(temp, num)
    print(temp)

main()
