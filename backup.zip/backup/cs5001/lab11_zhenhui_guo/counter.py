import sys

def print_number(current, number):
    print(current)
    if current < number:
        print_number(current + 1, number)


def main():
    number = int(sys.argv[1])
    print_number(1, number)

main()