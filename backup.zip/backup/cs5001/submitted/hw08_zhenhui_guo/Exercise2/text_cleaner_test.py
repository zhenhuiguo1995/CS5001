from text_cleaner import TextCleaner
import io

file_name = "corpse_bride.txt"
Test = TextCleaner(file_name)


def test_read_file():
    """
    Test the read_file method in the TextCleaner class.
    """
    assert Test.file_name == file_name
    assert Test.file is None
    assert Test.string_list == []
    Test.read_file()
    assert type(Test.file) == io.TextIOWrapper
    assert Test.string_list == []


def test_do_clean():
    """
    Test the do_clean method in the TextCleaner class.
    """
    Test.read_file()
    assert Test.string_list == []
    Test.do_clean()
    assert len(Test.string_list) > 0
