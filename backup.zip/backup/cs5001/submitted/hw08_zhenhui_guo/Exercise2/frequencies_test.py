from ngram_frequencies import NgramFrequencies
from text_cleaner import TextCleaner

Test = TextCleaner("corpse_bride.txt")
Test.read_file()
Test.do_clean()
Ngram = NgramFrequencies(Test.string_list, 1)


def test_add_item():
    """Test the add_item method in the NgramFrequencies class."""
    assert "the" not in Ngram.d.keys()
    Ngram.add_item("what")
    assert Ngram.d["what"] == 1
    for _ in range(10):
        Ngram.add_item("hi")
    assert Ngram.d["what"] == 1
    assert Ngram.d["hi"] == 10


def test_top_n_counts():
    """Test the top_n_counts method in the NgramFrequencies class."""
    for _ in range(5):
        Ngram.add_item("the")
        Ngram.add_item("a")
        Ngram.add_item("as")
    for _ in range(4):
        Ngram.add_item("by")
        Ngram.add_item("the")
    for _ in range(3):
        Ngram.add_item("a")
        Ngram.add_item("hello")
    for _ in range(2):
        Ngram.add_item("as")
        Ngram.add_item("world")
        Ngram.add_item("up")
        Ngram.add_item("god")
    for _ in range(100):
        Ngram.add_item("oh")
    assert Ngram.top_n_counts()[0:10] == [
        ("oh", 100), ("hi", 10), ("the", 9), ("a", 8), ("as", 7),
        ("by", 4), ("hello", 3), ("world", 2), ("up", 2), ("god", 2)
        ]


def test_top_n_freqs():
    """Test the top_n_counts method in the rgamFrequencies class."""
    assert Ngram.top_n_freqs()[0:10] == [
        ("oh", 100/148), ("hi", 10/148), ("the", 9/148), ("a", 8/148),
        ("as", 7/148), ("by", 4/148), ("hello", 3/148), ("world", 2/148),
        ("up", 2/148), ("god", 2/148)
        ]


def test_freq():
    """Test the freq method in the NrgamFrequencies class"""
    assert Ngram.freq("oh") == 100/148
    assert Ngram.freq("what") == 1/148


def test_count_freqs():
    """Test the count_freqs method in the NgramFrequencies class"""
    temp = TextCleaner("corpse_bride.txt")
    temp.read_file()
    temp.do_clean()
    temp = NgramFrequencies(temp.string_list, 2)
    temp.count_freq()
    assert temp.freq("COMMA_the") == 0.015968063872255488
    assert temp.freq("in_the") == 0.00998003992015968
