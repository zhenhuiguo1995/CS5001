class NgramFrequencies:
    """
    The NgramFrequency class which calculates the frequency
    of each specific instance of this class.
    """
    def __init__(self, string_list, count):
        self.d = {}
        # self.string_list contains the list of strings to be processed
        self.string_list = string_list
        # self.grams indeciates the type of gram of this object
        self.grams = count
        # self.total_grams records the total number of grams.
        self.total_grams = 0

    def add_item(self, item):
        """
        Takse an Ngram and increases its count in the dictionary.
        """
        if item in self.d:
            self.d[item] += 1
        else:
            self.d[item] = 1
        self.total_grams += 1

    def top_n_counts(self):
        """
        Returns a list of items and its countes stored in the dictionary,
        in descending order of counts.
        """
        return sorted(self.d.items(), key=lambda x: x[1], reverse=True)

    def top_n_freqs(self):
        """
        Returns a list containing items and its frequencies in the
        dictionary, in descedning order or frequencies.
        """
        temp = self.d.keys()
        dictionary = {}
        for key in temp:
            dictionary[key] = self.d[key]/self.total_grams
        return sorted(dictionary.items(), key=lambda x: x[1], reverse=True)

    def freq(self, item):
        """
        Returns the frequency of the item.
        """
        return self.d[item]/self.total_grams

    def count_freq(self):
        """
        Loop through the list and add every item to self.d
        """
        for sentence in self.string_list:
            for i in range(len(sentence) - (self.grams - 1)):
                string = ""
                if self.grams == 1:
                    string = sentence[i]
                elif self.grams == 2:
                    string = sentence[i] + "_" + sentence[i+1]
                elif self.grams == 3:
                    string += sentence[i] + "_"
                    string += sentence[i + 1] + "_"
                    string += sentence[i + 2]
                self.add_item(string)
