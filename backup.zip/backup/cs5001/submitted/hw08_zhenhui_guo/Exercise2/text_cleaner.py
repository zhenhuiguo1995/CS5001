import re


class TextCleaner:
    """An object which processed text and store it as a 2-d list"""
    def __init__(self, file_name):
        """
        """
        self.file_name = file_name
        self.file = None
        self.string_list = []

    def read_file(self):
        """Read the file and bind the name to self.file
        None -> None"""
        try:
            self.file = open(self.file_name)
        except:
            print("Can't open {0}".format(self.file_name))
            return

    def do_clean(self):
        """
        Convert the file object to a 2-d list.
        The second dimensional represents sentences.
        """
        for line in self.file:
            line = line.rstrip().replace("(", " ").replace(")", " ")
            line = line.replace("\"", " ").replace("Mr.", "Mr")
            line = line.replace("-", "").lower().replace(",", " COMMA")
            line = line.split(".")
            for item in line:
                letters = item.split()
                if letters != []:
                    self.string_list.append(letters)
