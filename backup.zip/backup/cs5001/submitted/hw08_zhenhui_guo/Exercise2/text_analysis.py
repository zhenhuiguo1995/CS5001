from text_cleaner import TextCleaner
from ngram_frequencies import NgramFrequencies
import sys


def read_and_print(file_name, grams=1):
    """Given a string representing the name of the file and an integer
    representing the type of the grams, prints out the top n frequencies
    of the grams in the file.
    String Integer -> None"""
    preprocess = TextCleaner(file_name)
    preprocess.read_file()
    preprocess.do_clean()
    ngram_object = NgramFrequencies(preprocess.string_list, grams)
    ngram_object.count_freq()
    tuples = ngram_object.top_n_freqs()[0:10]
    if grams == 1:
        print("Top 10 unigrams:")
    elif grams == 2:
        print("Top 10 bigrams:")
    else:
        print("Top 10 trigrams:")
    for element in tuples:
        print("\t", element)


def main():
    """prints out the unigram, bigram and trigram in the given file.
    None -> None"""
    file_name = sys.argv[1]
    try:
        open(file_name)
    except:
        print("Can't open file {0}".format(file_name))
        return
    read_and_print(file_name, 1)
    read_and_print(file_name, 2)
    read_and_print(file_name, 3)

main()
