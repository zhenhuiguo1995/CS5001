class PrimeGenerator:
    """Generates the primes numbers under the given n
    with the sieve of Eratosthenes"""
    def __init__(self):
        """Initialized class attribute composite as an empty set.
        None -> None"""
        self.composite = set()

    def primes_to_max(self, n):
        """Given an integer n, returns a list of prime numbers less than n.
        Integer -> List"""
        i = 3
        # If i is not a composite, put all multiples of i into composite.
        while i ** 2 <= n:
            if i not in self.composite:
                self.mark_composite(i, n)
            i += 2
        # all_numbers containes odd numbers less than n, excluding 1.
        all_numbers = set(list(range(3, n, 2)))
        # all_numbers also should include 2.
        all_numbers.add(2)
        return list(all_numbers.difference(self.composite))

    def mark_composite(self, start, end):
        """Given two integers start and end, add all multiples of start
        into the composite set.
        None -> None"""
        for i in range(start * 2, end + 1, start):
            self.composite.add(i)
