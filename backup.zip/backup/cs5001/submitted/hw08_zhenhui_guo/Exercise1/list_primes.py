from prime_generator import PrimeGenerator


def main():
    """prints out the list of prime numbers less than 1000000.
    None -> None"""
    prime = PrimeGenerator()
    prime_list = prime.primes_to_max(1000000)
    # Takes less than 0.4s on my computer.
    print(sorted(prime_list))

main()
