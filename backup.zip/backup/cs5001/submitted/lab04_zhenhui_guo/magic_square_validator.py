#change the input number to a list
def number_to_digits(num):
    list = []
    while num > 0: 
        list.append(num%10)
        num //= 10
    list.reverse()
    return list


def main():
    temp = []
    print("Enter a magic number")
    for _ in range(0, 3):
        a = int(input(""))
        list = number_to_digits(a)
        temp.append(list)
    is_magic = True
    
    #check every row 
    for i in range(0, 3):
        if temp[i][0]+temp[i][1]+temp[i][2] != 15:
            is_magic = False
    
    #check every colomn
    for i in range(0, 3):
        if temp[0][i] + temp[1][i] + temp[2][i]!= 15:
            is_magic = False
    
    #check two diagonals 
    if temp[0][0] + temp[1][1] + temp[2][2] != 15:
        is_magic = False
    if temp[2][0] + temp[1][1] + temp[0][2] != 15:
        is_magic = False

    if is_magic:
        print("This is a magic square!")
    else:
        print("Not a magic square!")     

main()