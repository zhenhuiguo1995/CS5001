import sys

def main():
    symbol = sys.argv[1]
    width = int(sys.argv[2])
    height = int(sys.argv[3])
    if height < 2 or width < 2:
        if height < 2:
            print("Too small value for height!")
        if width < 2:
            print("Too small value for width!")
    else:
        print(symbol*width)
        for _ in range(1, height -1):
            print(symbol + " "*(width-2)+ symbol)
        print(symbol*width)

main()
