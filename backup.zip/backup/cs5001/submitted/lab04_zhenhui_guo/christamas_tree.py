def main():
    width = int(input("Please give an odd number which is no " 
            + "less than 3 representing the width of the tree: "))
    while(width % 2 == 0 or width < 3):
        width = int(input("Please give an odd number which is no " 
        + "less than 3 representing the width of the tree: "))
    print(" " * (width//2) + "*" + " " * (width//2) )
    for i in range(1, width//2):
        print(" "*(width//2 - i) + "/"  + " "*(2*i - 1) + "\\")
    print("/" + "_" * (width-2) + "\\")

main()

