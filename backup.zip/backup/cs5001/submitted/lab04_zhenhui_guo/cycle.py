import sys
import math

def main():
    radius = int(sys.argv[1])
    diameter = radius * 2
    for i in range(0, diameter):
        length = math.ceil(math.sqrt(radius**2 - (abs(radius-i))**2) * 2)
        blank_space = (diameter - length)//2
        print(" " * blank_space + "o" * length + " "*blank_space)

main()