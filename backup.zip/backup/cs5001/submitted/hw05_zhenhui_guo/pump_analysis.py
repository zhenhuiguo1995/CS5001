def cal_time(amount, pumping_record, effective_power):
    """Calculates how long it takes to reach a given amount"""
    temp = 0
    is_achievable = False
    for i in range(len(pumping_record)):
        if pumping_record[i] > effective_power and temp < amount:
            temp += 2
        if temp >= amount:
            is_achievable = True
            break
    if is_achievable:
        print("It took {0} minutes of data to reach {1} gallons\n \
            ".format(i + 1, amount))
    else:
        print("It took {0} minutes of data to reach {1} gallons\n \
            ".format(-1, amount))


# This function calculates if the pump has a continuous long period of running
def cal_long_run(list, effective_power):
    """Calculates if the pump has a continuous long period of running"""
    count = 0
    res = []
    for i in range(len(list)):
        if list[i] > effective_power:
            count += 1
        else:
            if count >= 120:
                res.append((count - 1, i - count))
            count = 0
    print("Information on water softener recharges: \n")
    if not res:
        print("No information on water softener recharges available")
    else:
        for (i, j) in res:
            print("{0} minutes run started at {1}\n".format(i + 1, j + 1))


def main():
    # get user input and open the file
    file_name = input("Please enter the file name: ")
    try:
        file = open(file_name)
    except:
        print("Unable to open {0}".format(file_name))
        return

    # loop through every line of the file and get the data needed
    running_time = 0
    power = 0
    pump_record = []
    for line in file:
        temp = int(line.rstrip())
        pump_record.append(temp)
    power = sum(pump_record)
    minute = len(pump_record)

    # determining the effective_power, which determines the pump is running
    # data bigger than 900 are considered valid
    # whereas data less than 100 are considered invalid
    # I'll make the average of data between 100 and 900 as the effective_power
    # for the pump_data.txt, after calculating, effective_power = 515
    res = []
    for num in pump_record:
        if num > 100 and num < 900:
            res.append(num)
    if len(res) != 0:
        effective_power = sum(res)//len(res)
    else:
        effective_power = 900

    # apply the filtering criteria to the data and get water production
    for num in pump_record:
        if num > effective_power:
            running_time += 1

    # calculating the duration of the data
    hours = minute/60
    days = minute/1440
    print("Data covers a total of {0} hours".format(hours))
    print("(That's {0} days)\n".format(round(days, 4)))

    # calculating the amount of water so far, and get its average
    gallon = running_time*2
    gallon_per_day = gallon/days
    print("Pump was running {0} minutes, producing {1} gallons \
        ".format(running_time, gallon))
    print("That's {0} gallons per day\n \
        ".format(round(gallon_per_day, 4)))

    # calculating the amount of electricity
    power_in_kwh = power/(1000*60)
    print("Pump required a total of {0} watt minutes of power \
         ".format(power))
    print("That's {0} kWh\n".format(round(power_in_kwh, 4)))

    # calculating if the pump can produce given amount of water
    water1 = 5
    water2 = 100
    cal_time(water1, pump_record, effective_power)
    cal_time(water2, pump_record, effective_power)

    # calculating extra credit question
    cal_long_run(pump_record, effective_power)

main()
