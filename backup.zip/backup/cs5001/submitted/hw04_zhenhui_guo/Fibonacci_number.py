import sys


def main():
    max = int(sys.argv[1])
    list = [0, 1]
    for i in range(2, max):
        list.append(list[i-1]+list[i-2])
    print(list)

main()
