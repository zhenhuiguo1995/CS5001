# Name: Zhenhui Guo

import random as rnd


# generates the username
def username_generator(first_name, last_name):
    user_name = first_name[0:1]
    if len(last_name) < 7:
        user_name += last_name.lower()
        user_name += "*" * (7 - len(last_name))
    else:
        user_name += last_name[0:7]
    user_name += str(rnd.randint(0, 99))
    user_name = user_name.lower()
    return user_name


# generates the first password by concatenating first name, a random number
# and last name together and replace the specifies characters
def first_password(first_name, last_name):
    password1 = first_name + str(rnd.randint(0, 99)) + last_name
    password1 = password1.lower().replace('a', '@').replace('o', '0')
    password1 = password1.replace('l', '1').replace('s', '$')
    return password1


# generate the second password by getting and concatenating the first
# and last character of first name, last name and favorite word
def second_password(first_name, last_name, favorite_word):
    password2 = (first_name[0:1].lower() + first_name[-1].upper() +
                 last_name[0:1].lower() + last_name[-1].upper() +
                 favorite_word[0:1].lower() + favorite_word[-1].upper())
    return password2


# generate the last password by randomly get three lengths
#  and get the corresponding length of the string
def third_password(first_name, last_name, favorite_word):
    length1 = rnd.randint(0, len(first_name))
    length2 = rnd.randint(0, len(last_name))
    length3 = rnd.randint(0, len(favorite_word))
    password3 = last_name[0: length2] + favorite_word[0:length3]
    password3 += first_name[0:length1]
    return password3


def main():
    # get user information
    print("Welcome to the username and password generator!")
    first_name = input("Please enter your first name: ")
    first_name = first_name[0:1].upper() + first_name[1:].lower()
    last_name = input("Please enter your last name: ")
    last_name = last_name[0:1].upper() + last_name[1:].lower()
    favorite_word = input("Please enter your favorite word: ")
    favorite_word = favorite_word[0:1].upper() + favorite_word[1:].lower()

    # generate the username
    user_name = username_generator(first_name, last_name)
    print("\nThanks {0}, your user name is {1}\n \
        ".format(first_name, user_name))

    # generate passwords
    password1 = first_password(first_name, last_name)
    password2 = second_password(first_name, last_name, favorite_word)
    password3 = third_password(first_name, last_name, favorite_word)

    # print passwords
    print("Here are three suggested passwords for you to consider:\n")
    print("Password 1: {0}".format(password1))
    print("Password 2: {0}".format(password2))
    print("Password 3: {0}".format(password3))
    
main()
