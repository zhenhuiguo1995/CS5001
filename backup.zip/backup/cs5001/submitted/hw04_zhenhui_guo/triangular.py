import sys


def main():
    max = int(sys.argv[1])
    total = 0
    for i in range(1, max+1):
        total += i
    print(total)

main()