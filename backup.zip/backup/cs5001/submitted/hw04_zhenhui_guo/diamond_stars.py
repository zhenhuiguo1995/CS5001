import sys
import math


# This function calculates how many stars each line will output
def cal_stars_each_line(max):
    star_nums__each_line = []
    if max % 2 == 1:
        for i in range(0, max//2):
            star_nums__each_line.append(2 * i + 1)
        star_nums__each_line.append(max)
        for i in range(max//2+1, max):
            star_nums__each_line.append(max * 2 - (2 * i + 1))

    else:
        for i in range(0, max//2):
            star_nums__each_line.append(2*i+1)
        for i in range(max//2, max):
            star_nums__each_line.append(max-1 - (i-max//2) * 2)
    return star_nums__each_line


def main():
    # get the line of output and calculates
    # how many stars each line will have to output
    max = int(sys.argv[1])
    list = cal_stars_each_line(max)

    # loop from the 0th to the last line and print out
    for i in range(0, max):
        max_length = list[len(list)//2]
        blank_space = (max_length - list[i])//2
        print(" " * blank_space + "*" * list[i])

main()
