import sys


def nosecone(width):
    """
    print the nosecone part
    """
    if width % 2 == 1:
        start = 1
    else:
        start = 2
    while start < width:
        blank_space = (width - start)//2
        print(" " * blank_space + "*" * start + " " * blank_space)
        start += 2


def fuselage(width, length, optional=None):
    """
    print the fuselage part
    """
    for _ in range(length):
        if optional:
            for _ in range(width//2):
                print("_" * width)
            for _ in range(width//2, width):
                print("X" * width)
        else:
            for _ in range(width):
                print("X" * width)


def tail(width):
    """
    print the tail part
    """
    start = width // 2
    if start % 2 == 0:
        start += 1
    while start <= width:
        blank_space = (width - start)//2
        print(" " * blank_space + "*"*start + " "*blank_space)
        start += 2
    print("*" * (start-2))


def draw_rocket(width, length, optional):
    """
    print the whole rocket
    """
    nosecone(width)
    fuselage(width, length, optional)
    tail(width)


def main():
    width = int(sys.argv[1])
    length = int(sys.argv[2])
    if len(sys.argv) == 4:
        optional = sys.argv[3]
    else:
        optional = None
    draw_rocket(width, length, optional)

main()
