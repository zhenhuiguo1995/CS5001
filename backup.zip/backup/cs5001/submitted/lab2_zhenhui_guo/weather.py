#recording data of predicted temperatures for the coming 10 days  
highest = 67
lowest = 49
noon_1 = 61
noon_2 = 60
noon_3 = 61
noon_4 = 58
noon_5 = 58
noon_6 = 60
noon_7 = 62
noon_8 = 62
noon_9 = 61
noon_10 = 63

diff = highest - lowest
print("The difference between the highest and the lowest temperature values predicated for the 10 day forcast is", diff, "F")

aver_temp = (noon_1 + noon_2 + noon_3 + noon_4 + noon_5 + noon_6 + noon_7 + noon_8 + noon_9 + noon_10)/10
print("The average temperature at noon predicted for the 10 day forcast is", aver_temp,"F")


#converting from celsius to fahren
def celsius_to_fanhren(celsius):
    F = celsius * 9/5 + 32
    return F

def main():
    celsius = float(input("Please input a celsius degree:"))
    fahren =  celsius_to_fanhren(celsius)
    print(celsius,"Celsius Degree is",fahren,"F")
    return 0

main() 

