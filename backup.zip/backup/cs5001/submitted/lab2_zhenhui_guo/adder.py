def main():
    num1 = float(input("Enter a first value:")) 
    num2 = float(input("Enter a second value:"))
    result = num1 + num2
    print("The sum of", num1,"+",num2,"is",result)
    return 0
    
main()
