import math

def main():
    x1 = float(input("Input the x value of the first point:"))
    y1 = float(input("Input the y value of the first point:"))
    x2 = float(input("Input the x value of the second point:"))
    y2 = float(input("Input the y value of the second point:"))
    dist = math.sqrt((x1 - x2)**2 + math.pow((y1 - y2), 2))
    print("The Euclidean distance between the two points is", round(dist, 2))
    return 0
    
main()
