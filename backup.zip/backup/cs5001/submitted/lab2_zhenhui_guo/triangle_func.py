import math

def main():
    angle = float(input("Enter an angle: "))
    angle_in_radian = math.radians(angle)
    #angle_in_radian = angle * math.pi/180
    print("The cosine of", angle,"is",round(math.cos(angle_in_radian), 2))
    print("The sine of", angle, "is", round(math.sin(angle_in_radian), 2))

main()