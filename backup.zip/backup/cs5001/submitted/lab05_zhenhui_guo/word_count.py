import re


def main():
    # read and open the file
    file_name = input("Please enter the name of the file: ")
    try:
        file = open(file_name)
    except:
        print("Can't open {0}".format(file_name))
        return

    # initializing
    word = 0
    character = 0
    letter = 0
    # read the file by line and calculate
    # the word, character, letter count each line
    for line in file:
        line_string = line.split()
        word += len(line_string)
        for element in line_string:
            character += len(element)
        letter += len(re.findall(r'\w', line))

    # print out the result
    print("Words: {0}".format(word))
    print("Characters: {0}".format(character))
    print("Letters & numbers: {0}".format(letter))


main()
