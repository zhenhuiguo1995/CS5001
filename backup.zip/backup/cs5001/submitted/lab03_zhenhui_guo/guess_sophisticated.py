import random as rnd


def main():
    print("Welcome to the Guessing Game!")    
    
    #generate the random number and have the user guess the first time
    number = rnd.randint(1, 50)
    user_guess = int(input("I picked a number between 1 and 50. Try and guess!\n"))
    counter = 1 
    print("You guessed",user_guess)
    message = "Your guess is "
    
    while user_guess != number:
        dis = abs(user_guess - number)
        if dis <= 1:
            user_guess = int(input(message+"scalding hot\n"))
        elif dis <= 2:
            user_guess = int(input(message+"extremely warm\n"))
        elif dis <= 3:
            user_guess = int(input(message+"very warm\n"))
        elif dis <= 5:
            user_guess = int(input(message+"warm\n"))
        elif dis <= 8:
            user_guess = int(input(message+"cold\n"))
        elif dis <= 13:
            user_guess = int(input(message+"very cold\n"))
        elif dis <= 20:
            user_guess = int(input(message+"extremely cold\n"))
        else:
            user_guess = int(input(message+"ice freezing miserably cold\n"))
        counter += 1
    
    if counter == 1:
        print("That was lucky!")
    elif counter >= 2 and counter <= 4:
        print("That was amazing!")
    elif counter >= 5 and counter <= 6:
        print("That was okay.")
    elif counter == 7:
        print("Meh.")
    elif counter >= 8 and counter <= 9:
        print("This is not your game.")
    else:
        print("You are the worst guesser I've ever seen.")
        
main()
