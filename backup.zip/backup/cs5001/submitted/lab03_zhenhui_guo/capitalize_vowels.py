def captilize_vowels(word):
    lower_case = word.lower()
    tmp = ""
    for l in lower_case:
        if l in ['a', 'e', 'i', 'o', 'u']:
            tmp += l.upper()
        else:
            tmp += l
    return tmp


def main():
    string = input('Please input a random string as you wish: ')
    result = captilize_vowels(string)
    print(result)

main()
