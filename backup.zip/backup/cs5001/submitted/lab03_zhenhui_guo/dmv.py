import random as rnd

#capitalize the first letter of a name and lower the rest letters of the name
def capitalize_first(word):
    word = word[0].upper() + word[1:].lower()
    return word

def main():
    print("Welcome to the DMV (estimated wait time is 3 hours)")
    
    #process name info 
    name_info = input("Please enter your first, middle, and last name:\n")
    name_list = name_info.split()
    
    #separate the first name
    fn = capitalize_first(str(name_list[0]))
    
    #keep every middle name
    mn_list = name_list[1:len(name_list)-1]
    mn_count = len(mn_list)
    mn_str = ""
    for i in range(0, mn_count):
        mn_str += capitalize_first(mn_list[i] +" ")
    
    #keep last name
    ln = capitalize_first(str(name_list[len(name_list)-1]))

    #process date of birth info
    DoB_info = input("Enter date of birth (MM/DD/YY):\n")
    DoB_parsed = DoB_info.split('/')

    #generate a random license number
    license_number = rnd.randint(1000000, 9999999)
    
    #printing information
    print("---------------------------------------------------")
    print("Washington Driver License")
    print("DL",license_number)
    print('LN', ln)
    print("FN", fn, mn_str)
    print("DOB", DoB_info)
    print("EXP",str(DoB_parsed[0])+"/"+str(DoB_parsed[1])+"/"+str(21))

main()