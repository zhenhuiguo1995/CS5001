from stack import Stack

def reverse_string(string):
    temp = Stack()
    for letter in string:
        temp.push(letter)
    reverse = ""
    while not temp.is_empty():
        reverse += temp.pop()
    return reverse

def main():
    string = input("Please enter a string: ")
    reverse = reverse_string(string)
    print("The reverse of {0} is {1}".format(string, reverse))  

main()  
