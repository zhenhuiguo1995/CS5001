from stack import Stack


class StringProcessor:
    """Class for processing strings"""
    def process_string(self, line):
        """Given a string, returns a string.
        String -> String."""
        stack = Stack()
        special_singal = ["*", "^"]
        solution_string = ""
        for letter in line:
            if letter not in special_singal:
                stack.push(letter)
            else:
                if letter == "*":
                    if stack.items != []:
                        solution_string += stack.pop()
                else:
                    if len(stack.items) >= 2:
                        solution_string += stack.pop()
                        solution_string += stack.pop()
                    elif len(stack.items) == 1:
                        solution_string += stack.pop()
        return solution_string