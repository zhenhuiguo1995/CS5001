from stack import Stack


class BracketMatch:
    """Class for evaluating parenthetical strings"""
    # TODO: Implement bracket matching functionality
    # as required by bracket_checker.py and by
    # bracket_match_test.py
    def brackets_match(self, line):
        """Given a string, returns a bool value.
        String -> BOoolean"""
        d = {'(':')', '[':']', '{':'}'}
        open_brackets = ['(', '[', '{']
        close_bracktes = [')', ']', '}']
        stack = Stack()
        for letter in line:
            if letter in open_brackets:
                stack.push(letter)
            elif letter in close_bracktes:
                if len(stack.items) == 0:
                    return False
                else:
                    temp = stack.pop()
                    if d[temp] != letter:
                        return False
        if len(stack.items) > 0:
            return False
        else:
            return True

