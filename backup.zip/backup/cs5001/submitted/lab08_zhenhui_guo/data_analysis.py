import re


class DataAnalysis:
    """ Analyze the data and record the most frequent
    languages and countries."""
    def __init__(self, file):
        """
        Given the name of a file as a string, bind it to the class attribute.
        String -> None.
        """
        self.file_name = file
        self.file_as_list = self.read_data()

    def read_data(self):
        """ Read the file, returns a list containing every line of the file.
        None -> List of strings"""
        try:
            file_object = open(self.file_name)
        except:
            print("Can't open {0}".format(self.file_name))
            return
        file_as_list = []
        for line in file_object:
            string = line.rstrip().split(",")
            file_as_list.append(string)
        return file_as_list[1:]

    def top_n_lang_freqs(self, N):
        """Given an integer N, return an N-length list of tuples representing
        languages and their frequencies, in descending order of frequency.
        Integer -> Tuples."""
        INDEX_OF_LANGUAGES = 6
        d = {}
        for line in self.file_as_list:
            if line[INDEX_OF_LANGUAGES] in d:
                d[line[INDEX_OF_LANGUAGES]] += 1
            else:
                d[line[INDEX_OF_LANGUAGES]] = 1
        temp = list(d.keys())
        for element in temp:
            d[element] /= len(self.file_as_list)
        return self.sort_and_return(d, N)

    def top_n_country_tlds_freqs(self, N):
        """Given an interger N, return an N-length list of tuples representing
        countries and their frequencies, in descending order of frequency.
        Integer -> Tuples."""
        INDEX_OF_COUNTRY_TLDS = 3
        d = {}
        for line in self.file_as_list:
            prefix = re.findall(r".*\.", line[INDEX_OF_COUNTRY_TLDS])
            domain = line[INDEX_OF_COUNTRY_TLDS][len(prefix[0]):]
            if len(domain) == 2:
                if domain in d:
                    d[domain] += 1
                else:
                    d[domain] = 1
        temp = list(d.keys())
        for element in temp:
            d[element] /= len(self.file_as_list)
        return self.sort_and_return(d, N)

    def sort_and_return(self, d, n):
        """Given a dictionary d and an integer n, return an n-list of tuples
        representing the keys and values, in descending order of values
        Dictionary, Integer -> Tuples."""
        return sorted(d.items(), key=lambda x: x[1], reverse=True)[0:n]
