import random as rnd


class Die():
    """initializes a dice object"""
    def __init__(self):
        self.current_value = 0

    def roll(self):
        self.current_value = rnd.randint(1, 6)
