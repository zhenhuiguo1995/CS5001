from game_controller import GameController


def main():
    print("-" * 30)
    print("Welcome to street craps!\n")
    print("Rules:")
    print("If you roll 7 or 11 on your first roll, you win.")
    print("If you roll 2, 3, or 6 on your first roll, you lose.")
    print("If you roll anything else, that\'s your \'point\', and")
    print("you keep rolling until you either roll your point")
    print("again(win) or roll a 7(lose)\n")
    gc = GameController()
    gc.start()


main()
