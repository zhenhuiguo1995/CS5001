from die import Die


class PairOfDice:
    """Initialize an object with two dices objects"""
    def __init__(self):
        self.die_1 = Die()
        self.die_2 = Die()

    def roll_dice(self):
        self.die_1.roll()
        self.die_2.roll()

    def current_value(self):
        return self.die_1.current_value + self.die_2.current_value
