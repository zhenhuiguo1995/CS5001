from pair_of_dice import PairOfDice
import sys


class GameController():
    """
    Manages rolling, scoring, user interaction
    """
    def __init__(self):
        self.score = 0
        self.point = 0
        self.win_list = [7, 11]
        self.lose_list = [2, 3, 6]
        self.dice = PairOfDice()

    def start(self):
        """start the roll"""
        temp = input("Press enter to roll the dice...\n")
        if self.point == 0:
            self.first_round()
        else:
            self.other_rounds()

    def first_round(self):
        """
        roll for the first time
        """
        self.dice.roll_dice()
        self.score = self.dice.current_value()
        if self.score in self.win_list:
            print("You rolled {}. You win!".format(self.score))
        elif self.score in self.lose_list:
            print("You rolled {}. You lose.".format(self.score))
        else:
            self.point = self.score
            print("Your point is {}.".format(self.point))
            self.start()

    def other_rounds(self):
        """
        roll for the second, third,... etc. time
        """
        self.dice.roll_dice()
        self.score = self.dice.current_value()
        if self.score == self.point:
            print("You rolled {0}. You win!".format(self.score))
            sys.exit()
        elif self.score == 7:
            print("You rolled {0}. You lose!".format(self.score))
            sys.exit()
        else:
            print("You rolled {0}.".format(self.score))
            self.start()
