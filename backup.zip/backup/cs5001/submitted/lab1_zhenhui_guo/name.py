name = input("Please input your name:")
print("Hello, there," + name)