def main():
    age = int(input("Please enter your age: "))
    restHR = int(input("Please enter your resting heart rate: "))
    # My restHR is 80.
    print("=======================================")

    #TODO: Fill in the rest of the necessary code here
    max_heart_rate = 208 - 0.7 * age
    heart_rate_reserve = max_heart_rate - restHR
    zone1_min = round(restHR + heart_rate_reserve * 0.5, 2)
    zone1_max = round(restHR + heart_rate_reserve * 0.6, 2)
    zone2_max = round(restHR + heart_rate_reserve * 0.7, 2)
    zone3_max = round(restHR + heart_rate_reserve * 0.8, 2)
    zone4_max = round(restHR + heart_rate_reserve * 0.93, 2)
    zone5_max = round(restHR + heart_rate_reserve * 1.00, 2)
    print("Your heart rate reserve is:", heart_rate_reserve,"bpm")
    print("Here is a breakdown of your training zones:")
    print("Zone 1:", zone1_min,"to",zone1_max,"bpm")
    print("Zone 2:", zone1_max+1,"to",zone2_max,"bpm")
    print("Zone 3:", zone2_max+1,"to",zone3_max,"bpm")
    print("Zone 4:", zone3_max+1,"to",zone4_max,"bpm")
    print("Zone 5:", zone4_max+1,"to",zone5_max,"bpm")
    print("=======================================")

main()