def num_to_list(num):
    """
    transfer the input number to a list
    """
    temp = []
    while num > 0:
        temp.append(num % 10)
        num //= 10
    return temp


def add_two_list(list_1, list_2):
    """
    add every correspounding numbers in the two lists together
    """
    temp = []
    length = min(len(list_1), len(list_2))
    for i in range(length):
        temp.append(list_1[i] + list_2[i])
    if len(list_1) < len(list_2):
        for i in range(length, len(list_2)):
            temp.append(list_2[i])
    else:
        for i in range(length, len(list_1)):
            temp.append(list_1[i])
    return temp


def count_carries(list_of_num):
    """
    count the number of carries
    """
    count = 0
    is_carry = False
    for digit in list_of_num:
        if is_carry:
            digit += 1
        if digit >= 10:
            digit %= 10
            is_carry = True
            count += 1
    return count


def main():
    num_1 = int(input("Please enter the first number: "))
    num_2 = int(input("Please enter the second number: "))
    num1_list = num_to_list(num_1)
    num2_list = num_to_list(num_2)
    num1_and_num2 = add_two_list(num1_list, num2_list)
    carries = count_carries(num1_and_num2)
    result = num_1 + num_2
    print("{0} + {1} = {2}".format(num_1, num_2, result))
    print("Number of carries: {0}".format(carries))

main()
