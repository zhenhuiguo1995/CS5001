import turtle
import math


def draw_circle(radian):
    """
    draw the circle and color it
    """
    turtle.penup()
    turtle.setposition(0, -radian)
    turtle.pendown()
    turtle.color(0.4, 1, 1)
    turtle.begin_fill()
    turtle.circle(radian)
    turtle.end_fill()
    turtle.pencolor('blue')
    turtle.circle(radian)


def draw_star(radian, length, angle):
    """
    draw the star and color it
    """
    x_coordinates = - length//2
    y_coordinates = math.sqrt((radian**2) - (length//2)**2)
    turtle.penup()
    turtle.setposition(x_coordinates, y_coordinates)
    turtle.pendown()
    turtle.color('red', 'yellow')
    turtle.begin_fill()
    full_angle = 360
    for i in range(5):
        turtle.forward(length)
        turtle.right(full_angle//2 - angle)
    turtle.end_fill()
    turtle.hideturtle()
    turtle.exitonclick()


def draw(radian, length, angle):
    """
    draw the whole image
    """
    turtle.hideturtle()
    draw_circle(radian)
    draw_star(radian, length, angle)


def main():
    angle = 36
    length = 500
    radian = (length/math.cos(math.radians(angle//2)))/2
    draw(radian, length, angle)

main()
