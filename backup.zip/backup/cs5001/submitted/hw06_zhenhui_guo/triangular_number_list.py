def triangular_number(num):
    """
    Returns the triangular number of a number
    """
    total = 0
    i = 1
    while i <= num:
        total += i
        i += 1
    return total


def main():
    """
    Ask for a number and calculates its triangular number
    If the user enters 'done', exit
    and returns the list of all triangular numbers so far
    """
    triangular_list = []
    is_done = False
    while not is_done:
        string = input("Enter a number, or enter 'done': ")
        if string == 'done':
            is_done = True
        else:
            number = int(string)
            temp = triangular_number(number)
            print("The triangular number for {0} is {1}".format(number, temp))
            triangular_list.append(temp)
    print(triangular_list)


main()
