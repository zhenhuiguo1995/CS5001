def draw_horizon_edge(n, time='first'):
    """
    draw the horizontal edegs
    """
    if time == 'first':
        print(" " * (n//2+1) + "+" + "-" * (2 * n) + "+")
    elif time == 'second':
        print("+" + "-" * (2 * n) + "+" + " " * (n//2) + "|")
    else:
        print("+" + "-" * (2 * n) + "+")


def draw_diagonal_edge(n):
    """
    draw the diagonal edges
    """
    for i in range(n//2):
        print(" " * (n//2 - i) + "/" + " " * 2 * n + "/" + " " * i + "|")


def draw_vertical_edge(n):
    """
    draw the vertical edegs
    """
    for _ in range(n//2-1):
        print("|" + " " * (2 * n) + "|" + " " * (n//2) + "|")
    print("|" + " " * (2 * n) + "|" + " " * (n//2) + "+")
    for i in range(n//2, n):
        print("|" + " " * (2 * n) + "|" + " " * (n-i-1) + "/")


def draw_cube(n):
    """
    draw the cube
    """
    draw_horizon_edge(n, 'first')
    draw_diagonal_edge(n)
    draw_horizon_edge(n, 'second')
    draw_vertical_edge(n)
    draw_horizon_edge(n, 'third')


def main():
    size = int(input("Input cube size (multiple of 2): "))
    draw_cube(size)


main()
