def luhn_algorithm(num):
    nums = [int(i) for i in num]
    length = len(nums)
    res = []
    for i in range(length):
        if (length - i) % 2 == 0:
            res.append((nums[i] * 2) % 10 + (nums[i] * 2)//10)
        else:
            res.append(nums[i])
    if sum(res) % 10 == 0:
        return True
    else:
        return False


def main():
    num = input("Please input an account number: ")
    is_valid = luhn_algorithm(num)
    if is_valid:
        print("{0} is a valid account number".format(num))
    else:
        print("{0} is not a valid account number".format(num))

main()
