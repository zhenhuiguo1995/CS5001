from player import Player


class Bench:
    """A class representing a sidelines bench"""
    def __init__(self):
        # TODO: Initialize the bench object with whatever
        # attributes and values it will need
        self.players = []

    def send_to_bench(self, player_name):
        # TODO: Put the player "onto the bench"
        # player name has to be a player object
        if player_name.is_on_bench is False:
            self.players.insert(0, player_name)
            player_name.is_on_bench = True
            print("Send {0} to bench".format(player_name.name))
        else:
            print("{0} is already on the bench".format(player_name.name))

    def get_from_bench(self):
        # TODO: Return the name of the player who has
        # been on the bench longest.
        if self.players:
            temp = self.players.pop()
            temp.is_on_bench = False
            return temp
        else:
            return None

    # TODO: Write the function that will display the
    # current list of players on the bench
    def show_bench(self):
        if self.players:
            print("The bench currently includes:")
            for player in self.players:
                print(player.name)
        else:
            print("The bench is empty")

    # TODO: Write any other methods that might be used
    # by the methods above.
    def cut_player_from_bench(self, player_name):
        temp = None
        for player in self.players:
            if player.name == player_name:
                temp = player
        if temp:
            self.players.remove(player)
