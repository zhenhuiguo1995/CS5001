from player import Player


class Team:
    """A class representing a dodgeball team"""
    # All methods in Python include arguments representing the object
    # itself. In the method definition, this is represented by the
    # `self` parameter.
    def __init__(self):
        self.name = "Anonymous Team"
        self.players = []

    # Another example of self. The method call only passes one argument,
    # the 'name; value. But the method definition must always include the
    # self parameter.
    def set_team_name(self, name):
        # TODO: set the team name
        self.name = name

    # Note again that `self` is the first parameter.
    def add_player(self, player_name, player_number, player_position):
        # TODO: call the Player class constructor with the appropriate
        # values to create a new player object, then add that
        # player object to the team's players list.
        player = Player(player_name, player_number, player_position)
        self.players.append(player)

    def cut_player(self, player_name):
        # TODO: Remove the player with the name player_name
        # from the players list.
        temp = None
        for player in self.players:
            if player.name == player_name:
                temp = player
        if temp:
            self.players.remove(temp)
            print("Cut {0} from team {1}".format(player_name, self.name))
        else:
            print("Player {0} is not on the team.".format(player_name))

    def is_position_filled(self, position):
        # TODO: Write the method that checks whether
        # there is currently at least one player on the team
        # occupying the requested position
        player_position = [player.position for player in self.players]
        if position in player_position:
            print("Yes, the {0} position is filled".format(position))
        else:
            print("No, the {0} position is not filled".format(position))

    # TODO: Write any necessary methods to support the methods
    # above, and write the method that will display (print to screen)
    # the full team roster in the following format:
    def line_up(self):
        print("The lineup for {0} is:".format(self.name))
        if self.players:
            for i in self.players:
                print("{0}\t\t{1}\t\t{2}".format(i.number, i.name, i.position))
        else:
            print("The team currently has no players.")
    #    The lineup for Seattle Scorpions is:
    #    15       Garcia          catcher
    #    55       Wiggins         corner
    #    99       McCann          sniper
