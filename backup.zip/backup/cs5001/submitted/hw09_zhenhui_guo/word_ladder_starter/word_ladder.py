from queue import Queue
from stack import Stack


class WordLadder:
    """A class providing functionality to create word ladders when the
    given words are of equal length"""
    def __init__(self, w1, w2, wordlist):
        """Given the first and last word of the ladder, and the set containing
        all English words with the same length, bind them to class attributes
        String String Set -> None"""
        self.first = w1
        self.last = w2
        self.set = wordlist
        self.stack = None
        self.queue = None
        self.alphabet_letters = [
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
            ]
        self.seen = set()

    def make_ladder(self):
        """Returns the stack if there exists a ladder, otherwise returns None
        None -> Stack object or None"""
        self.stack = Stack()
        self.stack.push(self.first)
        self.queue = Queue()
        self.queue.enqueue(self.stack)
        self.seen.add(self.first)
        while not self.queue.isEmpty():
            temp_stack = self.queue.dequeue()
            temp_string = temp_stack.peek()
            for i in range(len(temp_string)):
                for letter in self.alphabet_letters:
                    temp = temp_string[:i] + letter + temp_string[i+1:]
                    if temp in self.set and temp not in self.seen:
                        self.seen.add(temp)
                        copy = temp_stack.copy()
                        copy.push(temp)
                        if temp == self.last:
                            return copy
                        else:
                            self.queue.enqueue(copy)
