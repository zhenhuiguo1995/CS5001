from queue import Queue
from stack import Stack


class WordLadderExtra:
    """A class providing functionality to create word ladders when the
    given words are of different length"""
    def __init__(self, w1, w2, wordlist):
        """Given the first and last word of the ladder, and the set containing
        all English words with the same length, bind them to class attributes
        String String Dictionary -> None"""
        self.first = w1
        self.last = w2
        self.d = wordlist
        self.stack = None
        self.queue = None
        self.alphabet_letters = [
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
            ]
        self.seen = set()

    def make_ladder(self):
        """Returns the stack if there exists a ladder, otherwise returns None
        None -> Stack object or None"""
        self.stack = Stack()
        self.stack.push(self.first)
        self.queue = Queue()
        self.queue.enqueue(self.stack)
        self.seen.add(self.first)
        while not self.queue.isEmpty():
            temp_stack = self.queue.dequeue()
            temp_string = temp_stack.peek()
            # first change a letter
            change_letter = self.change_letter(temp_string)
            if change_letter != []:
                for word in change_letter:
                    copy = temp_stack.copy()
                    copy.push(word)
                    if word == self.last:
                        return copy
                    else:
                        self.queue.enqueue(copy)
            # then add a letter
            add_letter = self.add_letter(temp_string)
            if add_letter != []:
                for word in add_letter:
                    copy = temp_stack.copy()
                    copy.push(word)
                    if word == self.last:
                        return copy
                    else:
                        self.queue.enqueue(copy)
            # then delete a letter
            delete_letter = self.delete_letter(temp_string)
            if delete_letter:
                for word in delete_letter:
                    copy = temp_stack.copy()
                    copy.push(word)
                    if word == self.last:
                        return copy
                    else:
                        self.queue.enqueue(copy)

    def change_letter(self, word):
        """Given a word, returns a list of word if mutating a letter in
        the word generates a valid word.
        String -> List"""
        return_list = []
        for i in range(len(word)):
            for letter in self.alphabet_letters:
                temp = word[:i] + letter + word[i+1:]
                if temp in self.d[len(temp)] and temp not in self.seen:
                    self.seen.add(temp)
                    return_list.append(temp)
        return return_list

    def add_letter(self, word):
        """Given a word, returns a list of word if adding a random letter in
        the original word generates a valid word.
        String -> List"""
        return_list = []
        for i in range(len(word) + 1):
            for letter in self.alphabet_letters:
                temp = word[:i] + letter + word[i:]
                if temp in self.d[len(temp)] and temp not in self.seen:
                    self.seen.add(temp)
                    return_list.append(temp)
        return return_list

    def delete_letter(self, word):
        """Given a word, returns a list of word if deleting a random letter in
        the original word generates a valid word.
        String -> List"""
        return_list = []
        if len(word) > 1:
            for i in range(len(word)):
                temp = word[:i] + word[i+1:]
                if temp in self.d[len(temp)] and temp not in self.seen:
                    self.seen.add(temp)
                    return_list.append(temp)
            return return_list
        else:
            return None
