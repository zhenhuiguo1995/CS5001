from word_ladder import WordLadder
from stack import Stack
from word_ladder_extra import WordLadderExtra


def test_make_ladder():
    """Test word ladder class"""
    word_dict = load_words()
    # Testing data and code
    w1, w2 = 'data', 'code'
    ladder = WordLadder(w1, w2, word_dict[len(w1)])
    word_ladder = ladder.make_ladder()
    assert word_ladder.items == ['data', 'dada', 'dade', 'cade', 'code']
    assert len(word_ladder.items) == 5

    # Testing angel and devil
    w1, w2 = 'angel', 'devil'
    ladder = WordLadder(w1, w2, word_dict[len(w1)])
    word_ladder = ladder.make_ladder()
    assert word_ladder.items == [
        'angel', 'anger', 'aeger', 'leger',
        'lever', 'level', 'devel', 'devil'
        ]
    assert len(word_ladder.items) == 8

    # Testing earth and ocean
    w1, w2 = 'earth', 'ocean'
    ladder = WordLadder(w1, w2, word_dict[len(w1)])
    word_ladder = ladder.make_ladder()
    assert word_ladder.items == [
        'earth', 'barth', 'barih', 'baris', 'batis', 'bitis', 'aitis',
        'antis', 'antas', 'antal', 'ontal', 'octal', 'octan', 'ocean'
        ]
    assert len(word_ladder.items) == 14


def test_make_ladder_extra():
    """Test word ladder extra class"""
    word_dict = load_words()
    # Testing dog and puppy
    w1, w2 = 'dog', 'puppy'
    ladder = WordLadderExtra(w1, w2, word_dict)
    word_ladder = ladder.make_ladder()
    assert word_ladder.items == [
        'dog', 'cog', 'cop', 'copy', 'coppy', 'poppy', 'puppy'
        ]
    assert len(word_ladder.items) == 7

    # Testing sad and happy
    w1, w2 = 'sad', 'happy'
    ladder = WordLadderExtra(w1, w2, word_dict)
    word_ladder = ladder.make_ladder()
    assert word_ladder.items == [
        'sad', 'gad', 'gap', 'gapy', 'gappy', 'happy'
        ]
    assert len(word_ladder.items) == 6

    # Testing red and yellow
    w1, w2 = 'red', 'yellow'
    ladder = WordLadderExtra(w1, w2, word_dict)
    word_ladder = ladder.make_ladder()
    assert word_ladder.items == [
        'red', 'bed', 'bel', 'bell', 'bello', 'bellow', 'yellow'
        ]
    assert len(word_ladder.items) == 7

    # Testing command and line
    w1, w2 = 'command', 'line'
    ladder = WordLadderExtra(w1, w2, word_dict)
    word_ladder = ladder.make_ladder()
    assert word_ladder.items == [
        'command', 'commend', 'compend', 'comped',
        'coped', 'loped', 'lope', 'lone', 'line'
        ]
    assert len(word_ladder.items) == 9


def load_words():
    """Load words from complete wordlist file"""
    valid_words = {}
    with open('words_alpha.txt') as word_file:
        for w in word_file.read().split():
            if len(w) in valid_words.keys():
                # Add to an existing set
                valid_words[len(w)].add(w)
            else:
                # Initialize a set with one element
                valid_words[len(w)] = {w}
    return valid_words
