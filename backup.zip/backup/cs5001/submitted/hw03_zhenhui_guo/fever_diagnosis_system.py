# this function checks if the patient has aching bones or aching joints
def aching():
    message = "Possibilities include"
    patient_response = input("Do you have aching bones or aching joints? ")
    if patient_response == "Yes":
        print(message, "viral infection")
    else:
        patient_response = input("Do you have a rash? ")
        if patient_response == "Yes":
            print("Insufficient information to list possibilities.")
        else:
            patient_response = input("Do yu have a sore throat? ")
            if patient_response == "Yes":
                print(message, "a throat infection")
            else:
                patient_response = input("Do you have back pain just above the waits with chills and fever? ")
                if patient_response == "Yes":
                    print(message, "include kidney infection.")
                else:
                    patient_response = input("Do you have pain urinating or are urinating more often? ")
                    if patient_response == "Yes":
                        print(message, "a urinary tract infection.")
                    else:
                        patient_response = input("Have you spent the day in the sun or in hot conditions? ")
                        if patient_response == "Yes":
                            print(message, "sunstroke or heat exhaustion.")
                        else:
                            print("Insufficient information to list possibilities.")   


def main():
    print("Please type in Yes or No to answer the following questions")
    message = "Possibilities include"
    patient_response = input("Are you coughing? ")
    if patient_response == "Yes":
        patient_response = input("Are you short of breath or wheezing or coughing up phlegm? ")
        if patient_response == "Yes":
            print(message, "pneumonia or infection of airways")    
        else:
            patient_response = input("Do you have a headache? ")
            if patient_response == "Yes":
                print(message, "viral infection")
            else:
                aching()
    else:
        patient_response = input("Do you have a headache? ")
        if patient_response == "Yes":
            patient_response = input("Are you experiencing any of the following pain when bending your head forward, nausea or vomiting, bright light hurting your eyes, drowsiness or confusion? ")
            if patient_response == "Yes":
                print(message, "menigits.")
            else:
                patient_response = input("Are you vomiting or had diarrhea? ")
                if patient_response == "Yes":
                    print(message, "digestive tract infection.")
                else:
                    aching()
        else:
            aching()

main()





