import sys
from linked_list import LinkedList


def every_other(linked_list):
    e_o = LinkedList('')
    return every_other_node(e_o, linked_list.first)


def every_other_node(e_o, node):
    pass


def main():
    linked_list = LinkedList(sys.argv[1])
    print(every_other(linked_list))


main()
